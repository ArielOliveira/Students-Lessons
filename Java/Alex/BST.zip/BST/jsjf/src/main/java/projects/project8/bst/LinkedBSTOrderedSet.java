package projects.project8.bst;

import java.util.Iterator;

public class LinkedBSTOrderedSet<T> implements OrderedSetADT<T>{

	public LinkedBSTOrderedSet() {
		
	}

	@Override
	public void addElement(T element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public T removeElement(T targetElement) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T find(T targetElement) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T findMin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T findMax() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean contains(T targetElement) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return null;
	}
}
