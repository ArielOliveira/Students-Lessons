#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <cctype>
#include <sstream>
#include "helper.h"


using std::vector;
using std::string;
using std::map;
using std::cout;
using std::cin;
using std::endl;
using std::stringstream;

int getPhoneTypeIndex(string phoneType) {
  for (int i = 0; i < phoneType.length(); i++)
    phoneType[i] = toupper(phoneType[i]);

  int typeNumber = 0;
  for (typeNumber = 0; typeNumber < 5; typeNumber++) {
    if (phoneType.compare(phoneTypes[typeNumber]) == 0) {
      return typeNumber;  
    }
  }
  return -1;
}



int main() {

cout << "Info: Welcome to the Phone Database!" << endl;
cout << "Info: Please enter a command" << endl;

string command;
Database p;

while(cin >> command) {


if (command == "C") {
	string firstName;
	string lastName;
	cin >> lastName;
	cin >> firstName;

	//Contact* cname(lastName, firstName);
	

		if(!p.findByName(lastName, firstName)) {

			p.addContact(new Contact(lastName, firstName));
			cout << "Result: Contact Created" << endl;
	}
  
  	else {

			cout << "Error: Contact already exists" << endl;
	
	}
}

if (command == "D") {
//input function that deletes the contact
	string lastName;
	string firstName;
	cin >> lastName;
	cin >> firstName;

	Contact cname(lastName, firstName);

	if (p.deleteContact(cname)) {
		//p.deleteContact(cname);

		cout << "Error: Contact not Found" << endl;
	}

	else {
		cout << "Result: Contact Deleted" << endl;
	}

}

if (command == "N"){
	string lastName;
	string firstName;
	string phoneType;
	string phoneNumber;
	cin >> lastName;
	cin >> firstName;
	cin >> phoneType;
	cin >> phoneNumber;

  int typeNumber = getPhoneTypeIndex(phoneType);

  if (typeNumber == -1) {
    cout << "Wrong input: Aborting" << endl;
    exit(-1);
  }

	Contact* cname = p.findByName(lastName, firstName);

	//Contact cname(lastName, firstName);
	

		if(!cname) {
			cout << "Error: Contact not Found" << endl;
		}

		else if (phoneType != "CELL" && phoneType != "HOME" && phoneType != "WORK" && phoneType != "FAX" && phoneType != "VOIP") {
			cout << "Error: Invalid phone number type" << endl;
		}



		else if (phoneNumber.length()!= 12) {

		cout << "Error: Not a valid phone number" << endl;
	}

		else{
		// need to add contact to name
		cname->addNumber(typeNumber, phoneNumber);
		//make helper function updateVec(cname, lastName, firstName)
		for(int i=0; i < p.data.size(); i++) {
			Contact* temp = p.data[i];
			if (temp->ifMatch(lastName, firstName)) {
				p.data[i] = cname;

			}
			
		}
	// iterate through vector to find match in the vector, then update contact
		cout << "Result: Successfully Added Number" << endl;
		cout << cname->getPhoneType(typeNumber) << endl;
		//cout << cname->work << endl;
	}
}

if (command == "X") {
	string lastName;
	string firstName;
	string phoneType;
	cin >> lastName;
	cin >> firstName;
	cin >> phoneType;

  Contact* cname = NULL;

  cname = p.findByName(lastName, firstName);

  int typeNumber = getPhoneTypeIndex(phoneType);

  if (typeNumber == -1) {
    cout << "Wrong input: Aborting." << endl;
    exit(-1);
  }

	if(!cname) {
			cout << "Error: Contact not Found" << endl;
	} else if (cname->getPhoneType(typeNumber).compare("") == 0) {
    cout << "Error: No phone number of that type" << endl;
  } else {
		//need to access the element from N, edit the phoneType field, then update the vector with the new element.
    
		cname->deleteNumber(typeNumber);
		cout << "Result: Phone Number Deleted" << endl;
	}
}

if (command == "P") {
string lastName;
string firstName;
//((p.findByName(lastName, firstName)).ifMatch(lastName, firstName))
cin >> lastName;
cin >> firstName;

Contact *cname = p.findByName(lastName, firstName);

if (!cname) {
	cout << "Error: Contact not found" << endl;
}
else {
cname->printNumbers();
//cout << "test print" << endl;
	}
}


//}

if (command == "L") {
		//edit to make them print in alphabetical order
	p.listContacts();

	}

if (command == "S") {
	string fName;
	cin >> fName;

	std::ofstream file;
	file.open(fName);

  file << p.data.size() << endl;
	//for (Contact i : p) {
		for(int i=0; i < p.data.size(); i++) {
      file << *p.data[i] << endl;
		//file << p.data[i] << endl;
	}
}

if (command == "R") {
	  string fName;
	  cin >> fName;

	  std::ifstream file;
	  file.open(fName);
	  if (file.is_open()) {
  
	  int contactList;
	  string currentLine;
	  getline(file, currentLine);
	  stringstream ss(currentLine);
	  ss >> contactList;
  
	  for (int count=0; count < contactList; count++) {
      Contact contact;
		  file >> contact;
		  p.addContact(new Contact(contact));
	  }
	
	}else {
		cout << "Error: Could not open input file" << endl;
  }
}

if (command == "Q")
	break;
	
	}
	cout << "Info: Thank you for using the Phone Database!" << endl;
	return 0;
}



