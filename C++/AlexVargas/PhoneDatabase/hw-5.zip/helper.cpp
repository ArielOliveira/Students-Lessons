#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <cctype>
#include "helper.h"

using std::vector;
using std::string;
using std::map;
using std::cout;
using std::cin;
using std::endl;



/* for loop iterate through data and print each last, then first
 *
 */
void Database::listContacts() {
	for(vector<Contact*>::iterator it = data.begin(); it != data.end(); it++) {
	  Contact* temp = *it;
		temp->printName();
	}
};

Contact* Database::findByName(string lName, string fName) {
	
	for(vector<Contact*>::iterator it = data.begin(); it != data.end(); it++) {
	  //Contact temp = *it;
		if ((*it)->ifMatch(lName, fName)) {
			return *it;
		}
	}  
	return NULL;
}
int Database::deleteContact(Contact name) {
	for(vector<Contact*>::iterator it = data.begin(); it != data.end(); it++) {
	  //Contact temp = *it;
		if ((*it)->ifMatch(name.getLastName(), name.getLastName())) {
			data.erase(it);
			return 0;
		}
		
	}
			return 1;
}





void Contact::addNumber(int type, string phoneNumber) {

/*
		for(vector<Contact>::iterator it = data.begin(); it != data.end(); it++) {
	  //Contact temp = *it;
		if ((*it).ifMatch(lName, fName)) {
			break;
		}
	findByName()

			if (phoneType == "CELL") {
				it->cell = phoneNumber;
				cell = phoneNumber;
			}
			if (phoneType == "HOME") {
				it->home = phoneNumber;
			}
			if (phoneType == "WORK") {
				it->work = phoneNumber;
			}
			if (phoneType == "FAX") {
				it->fax = phoneNumber;
			}
			if (phoneType == "VOIP") {
				it->voip = phoneNumber;
			}
		*/
			/*if (phoneType == "CELL") {
				cell = phoneNumber;
			}
			if (phoneType == "HOME") {
				home = phoneNumber;
			}
			if (phoneType == "WORK") {
				work = phoneNumber;
			}
			if (phoneType == "FAX") {
				fax = phoneNumber;
			}
			if (phoneType == "VOIP") {
				voip = phoneNumber;
			}*/
      if (type < 5)
        phones[type] = phoneNumber;
		}


void Contact::deleteNumber (int type) {
    phones[type] = "";
			/*if (phoneType == "CELL") {
				cell = "";
			}
			if (phoneType == "HOME") {
				home = "";
			}
			if (phoneType == "WORK") {
				work = "";
			}
			if (phoneType == "FAX") {
				fax = "";
			}
			if (phoneType == "VOIP") {
				voip = "";
			}*/

}

Contact::Contact(const Contact& c) {
	firstName = c.firstName;
	lastName = c.lastName;
	for (int i=0; i < 5; i++) {
		phones[i] = c.phones[i];
	}
}


bool Contact::compareUpper(string x, string y) {
	for(int i=0; i<x.length(); i++) {
		x[i] = toupper(x[i]);
		y[i] = toupper(y[i]);
	}
	if (x.compare(y) == 0) {
		return true;
	}
	return false;
}
