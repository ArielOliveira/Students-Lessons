#ifndef HELPER_H
#define HELPER_H
#include <vector>
#include <string>
#include <ostream>
#include <istream>

using std::vector;
using std::string;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;

const string phoneTypes[] = {"CELL", "FAX", "HOME", "VOIP", "WORK"};

class Contact {
	private:
		string firstName;
		string lastName;
    string phones[5];
		bool compareUpper(string x, string y);

		//string home;
		//string cell;
		//string work;
		//string fax;
		//string voip;
	public:
    Contact() {firstName = ""; 
    lastName = ""; 
    for (int i = 0; i < 5; i++) phones[i] = "";}

		Contact(const Contact& c);

    void setFirstName(const string& name) { firstName = name; }
    string getFirstName() {return firstName;}

    void setLastName(const string& name) { lastName = name; }
    string getLastName() {return lastName;}

    string getPhoneType(int type) { if (type < 5) return phones[type]; }
    
		Contact(string lName, string fName) { lastName = lName; firstName = fName;
    for (int i = 0; i < 5; i++) phones[i] = ""; } //constructor uses string of first and last name
		void printNumbers() {
      for (int i = 0; i < 5; i++) {
				if (phones[i] != "") {
        cout << "Result: " << phoneTypes[i] << "," << phones[i] << endl;
				}
      }
		} // prints all strings that are not null for a specific contact (not including firstName and lastName)

		void addNumber(int type, string phoneNumber);

		bool ifMatch(string lName, string fName) { if (compareUpper(lName, lastName) && compareUpper(fName, firstName)) { return true; } };

		void printName() { cout << lastName + ", " + firstName << endl; };

		void changeNumber(string type, string number) {}; //using type, change number using switch case

		void deleteNumber (int type); //command X; make string of type specified to null (using switch case)

		friend ostream & operator << (ostream &out, const Contact &c) {
			out << c.lastName << "," << c.firstName << ",";
				for (int i=0; i < 4; i++) {
					out << c.phones[i] << ",";
				}
				out << c.phones[4];
			return out;
		}
		
		friend istream & operator >> (istream &input, Contact &c) {
			getline(input, c.lastName, ',');
			getline(input, c.firstName, ',');
			for (int i=0; i < 4; i++) {
			getline(input, c.phones[i], ',');
			}
			getline(input, c.phones[4]);


			return input;
		}
};

class Database {
	public: // change back to private
		vector<Contact*> data;

	//public:
		Database() { };

		void addContact(Contact* name) { data.push_back(name); };



		int deleteContact(Contact name);

		void listContacts(); //for loop iterate through data and print each last, then first

		Contact* findByName(string fName, string lName); //use string of first and last name and find using a for loop

		void printNumbers(string fName, string lName) {}; //use findByName to find the contact, then using the contact you compare to vector using a for loop. once found, use printNumbers in contact class


		void saveToFile() {}; //save to a file (print new line for every contact and list each phone number)

		void readFromFile() {}; //read from the saved file to the database

		

};
#endif

